package stepDefinitions;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;

import cucumber.api.java.After;
import cucumber.api.java.Before;

public class Hooks {
	
	static WebDriver driver;
	
	@Before("@Login1")
	public void setUp() {
		System.setProperty("webdriver.chrome.driver", "C:\\Users\\FATEEMA\\Downloads\\chromedriver.exe");
		driver = new ChromeDriver();
		System.out.println("in before sanity tagged hook");
	}
	
	@After("@Login1")
	public void after() {
		driver.close();
		System.out.println("in after sanity tagged hook");
	}
	
	@Before("@Success")
	public void before() {
		System.setProperty("webdriver.chrome.driver", "C:\\Users\\FATEEMA\\Downloads\\chromedriver.exe");
		driver = new ChromeDriver();
		System.out.println("in before success tagged hook");
	}
	
	@After("@Success")
	public void afterStep() {
		driver.close();
		System.out.println("in after success tagged hook");
	}
	
	

}
